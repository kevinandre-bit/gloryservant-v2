<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

// Admin vs Site controllers (alias to avoid name collisions)
use App\Http\Controllers\Admin\DashboardController as AdminDashboardController;
use App\Http\Controllers\DashboardController as SiteDashboardController;

use App\Http\Controllers\Admin\MeetingLinkController as AdminMeetingLinkController;
use App\Http\Controllers\MeetingLinkController as PublicMeetingLinkController;

use App\Http\Controllers\Admin\ReportsController as AdminReportsController;

use App\Http\Controllers\Admin\ProfileController;
use App\Http\Controllers\Admin\ComputerController;
use App\Http\Controllers\Admin\InventoryController;
use App\Http\Controllers\AttendanceReportsController;
use App\Http\Controllers\DevotionReportController;
use App\Http\Controllers\Admin\AdminDevotionController;
use App\Http\Controllers\Admin\AdminAsanaController;
use App\Http\Controllers\Admin\AdminAsanaPortfolioController;
use App\Http\Controllers\AttendanceController;
use App\Http\Controllers\AdminAttendanceController;
use App\Http\Controllers\SendMailController;
use App\Http\Controllers\DisplayAttendanceController;
use App\Http\Controllers\RequestController;
use App\Http\Controllers\AdminRequestController;
use App\Http\Controllers\UserTrackingController;
use App\Http\Controllers\Admin\AdminPortalController;
use App\Http\Controllers\DevotionPublicController;
use App\Http\Controllers\VolunteersController;
use App\Http\Controllers\VolunteersActivityController;
use App\Http\Controllers\RadioDashboard\DashboardController;
use App\Http\Controllers\RadioDashboard\ProgramScheduleController;
use App\Http\Controllers\RadioDashboard\PlayoutLogController;
use App\Http\Controllers\RadioDashboard\Tech\TechScheduleController;
use App\Http\Controllers\RadioDashboard\Tech\TechAssignmentsController;
use App\Http\Controllers\RadioDashboard\Tech\TechRotaController;
use App\Http\Controllers\RadioDashboard\Tech\TechCheckinsController;
use App\Http\Controllers\RadioDashboard\Tech\TechAvailabilityController;
use App\Http\Controllers\RadioDashboard\MaintenanceController;
use App\Http\Controllers\RadioDashboard\MonitoringController;
use App\Http\Controllers\RadioDashboard\ReportsController;
use App\Http\Controllers\RadioDashboard\Admin\RadioRegistryController;
use App\Http\Controllers\RadioDashboard\Admin\TechnicianRegistryController;
use App\Http\Controllers\RadioDashboard\Admin\PocRegistryController;
// --- Finance (Expenses) ---
use App\Http\Controllers\RadioDashboard\Finance\ExpenseController;
use App\Http\Controllers\RadioDashboard\Finance\RecurringController;
use App\Http\Controllers\RadioDashboard\Finance\VendorController;
// Admin Report Studio (UI only, fake data)
use App\Http\Controllers\RadioDashboard\Reports\ReportStudioController;
use App\Http\Controllers\RadioDashboard\Inventory\RadioInventoryController;
use App\Http\Controllers\RadioDashboard\Inventory\InventoryVendorsController;
use App\Http\Controllers\RadioDashboard\Admin\SitesDirectoryController;
use App\Http\Controllers\Admin\MeetingAttendanceController;
// routes/web.php
use App\Http\Controllers\SmallGroup\SmallGroupController;
use App\Http\Controllers\Wellness\WellnessController;

Route::prefix('wellness')->name('wellness.')->middleware(['auth'])->group(function () {
    Route::get('/',                 [WellnessController::class, 'dashboard'])->name('dashboard');

    // Check-ins
    Route::post('/checkins',        [WellnessController::class, 'storeCheckin'])->name('checkins.store');

    // Cases
    Route::get('/cases',            [WellnessController::class, 'casesIndex'])->name('cases.index');
    Route::get('/cases/{id}',       [WellnessController::class, 'caseShow'])->name('cases.show');

    // Case actions / transitions
    Route::post('/cases/{id}/assign',        [WellnessController::class, 'assign'])->name('cases.assign');
    Route::post('/cases/{id}/transition',    [WellnessController::class, 'transition'])->name('cases.transition');
    Route::post('/cases/{id}/propose-close', [WellnessController::class, 'proposeClose'])->name('cases.proposeClose');
    Route::post('/cases/{id}/approve-close', [WellnessController::class, 'approveClose'])->name('cases.approveClose'); // overseer only
});

Route::prefix('small-groups')->name('small.')->group(function () {
    Route::get('/',                      [SmallGroupController::class, 'index'])->name('index');
    Route::post('/',                     [SmallGroupController::class, 'storeGroup'])->name('store');
    Route::post('{group}/leader',        [SmallGroupController::class, 'updateLeader'])->name('leader');
    Route::post('{group}/members',       [SmallGroupController::class, 'syncMembers'])->name('sync');
    Route::delete('{group}/member/{person}', [SmallGroupController::class, 'removeMember'])->name('remove');
});
Route::middleware(['auth'])/*->prefix('admin')->name('admin.')*/->group(function () {
    // OLD (kept): list meeting links (admin UI)
    // routes/web.php (inside your auth group)
Route::put('meeting-links/{id}', [\App\Http\Controllers\Admin\MeetingLinkController::class, 'update'])
    ->name('meetings.update');

    // NEW (added): create/store a meeting link (modal form POST)
    Route::post('meeting-links', [AdminMeetingLinkController::class, 'store'])
        ->name('meetings.store');

    // OLD (kept): attendance analytics page
    Route::get('meeting-attendance', [AdminMeetingLinkController::class, 'attendanceView'])
        ->name('meetings.attendance');

    // OLD (kept): attendance data feed (if you already have this in your controller)
    Route::get('meeting-attendance/data', [AdminMeetingLinkController::class, 'getData'])
        ->name('meetings.attendance.data');
    Route::delete('meeting-links/{id}',[AdminMeetingLinkController::class, 'destroy'])->name('meetings.destroy');
});
// routes/web.php
Route::middleware('auth')->get('/admin/meeting-link/options', function () {
    return response()->json([
        'campuses'    => DB::table('tbl_form_campus')->distinct()->pluck('campus')->filter()->values(),
        'ministries'  => DB::table('tbl_campus_data')->distinct()->pluck('ministry')->filter()->values(),
        'departments' => DB::table('tbl_campus_data')->distinct()->pluck('department')->filter()->values(),
    ]);
})->name('meetings.options');
/*
|--------------------------------------------------------------------------
| Scan endpoint (the URL encoded inside the QR)
|--------------------------------------------------------------------------
| Users hit https://gloryservant.com/attendance/{token}
| We require auth so the scan records the current user.
*/
// Show the meeting info after scanning (no write)
// 1) Specific attendance routes FIRST
// Meeting Attendance (QR scan flow)
Route::middleware(['auth','throttle:10,1'])->get(
    'meeting-attendance/{token}',
    [MeetingAttendanceController::class, 'auto']
)->where('token', '[A-Za-z0-9\-_]+')
 ->name('meeting.attendance.auto');

/* 2) ...later in the file: any broad/wildcard routes
Route::middleware('auth')->get('{slug}', [PersonalController::class, 'show'])
    ->where('slug', '^(?!attendance/).+'); // EXCLUDE attendance prefix*/

Route::prefix('inventory')->name('inventory.')->group(function () {
    // Items
    Route::get('/inventory.index',               [RadioInventoryController::class, 'index'])->name('index');
    Route::get('/movements',      [RadioInventoryController::class, 'movements'])->name('movements');
    Route::get('/items/new',      [RadioInventoryController::class, 'create'])->name('items.create'); // UI only
    // Vendors
    Route::get('/vendors',        [InventoryVendorsController::class, 'index'])->name('vendors.index');
    Route::get('/vendors/new',    [InventoryVendorsController::class, 'create'])->name('vendors.create');
});

Route::prefix('reports')->name('reports.')->group(function () {
    Route::get('/studio',   [ReportStudioController::class, 'studio'])->name('studio');          // entry hub
    Route::get('/build',    [ReportStudioController::class, 'build'])->name('build');            // wizard
    Route::get('/preview/{type}', [ReportStudioController::class, 'preview'])->name('preview');  // assembled preview
});
 

Route::prefix('finance')->name('finance.')->group(function () {
    // Expenses
    Route::get('/expenses',            [ExpenseController::class, 'index'])->name('expenses.index');
    Route::get('/expenses/new',        [ExpenseController::class, 'create'])->name('expenses.create');

    // Recurring rules
    Route::get('/recurring',           [RecurringController::class, 'index'])->name('recurring.index');
    Route::get('/recurring/new',       [RecurringController::class, 'create'])->name('recurring.create');

    // Vendors (optional directory)
    Route::get('/vendors',             [VendorController::class, 'index'])->name('vendors.index');
    Route::get('/vendors/new',         [VendorController::class, 'create'])->name('vendors.create');
});


Route::prefix('radio/admin')->name('radio.admin.')->group(function () {
    // ===================== Stations =====================
    Route::get('/stations',                    [RadioRegistryController::class, 'index'])->name('stations.index');
    //Route::get('/stations/new',                [RadioRegistryController::class, 'create'])->name('stations.create');   // (kept)
    Route::post('/stations/new',               [RadioRegistryController::class, 'store'])->name('stations.store');     // (kept)
    Route::get('/stations/{station}/edit',     [RadioRegistryController::class, 'edit'])->name('stations.edit');
    Route::put('/stations/{station}',          [RadioRegistryController::class, 'update'])->name('stations.update');
    Route::delete('/stations/{station}',       [RadioRegistryController::class, 'destroy'])->name('stations.destroy');
    Route::post('/stations/{station}/toggle',  [RadioRegistryController::class, 'toggle'])->name('stations.toggle');   // On-Air switch
    // routes/web.php (inside your radio.admin group with the others)
    Route::get('/stations/geo/arrondissements/{department}', [RadioRegistryController::class, 'arrondissements'])
        ->name('stations.geo.arrondissements');
    Route::get('/stations/geo/communes/{arrondissement}',    [RadioRegistryController::class, 'communes'])
        ->name('stations.geo.communes');

    // ===================== Technicians =====================
    Route::get('/technicians',                     [TechnicianRegistryController::class, 'index'])->name('techs.index');
    Route::get('/technicians/new',                 [TechnicianRegistryController::class, 'create'])->name('techs.create'); // (kept)
    Route::post('/technicians/new',                [TechnicianRegistryController::class, 'store'])->name('techs.store');   // (kept)
    Route::get('/technicians/{technician}/edit',   [TechnicianRegistryController::class, 'edit'])->name('techs.edit');
    Route::put('/technicians/{technician}',        [TechnicianRegistryController::class, 'update'])->name('techs.update');
    Route::delete('/technicians/{technician}',     [TechnicianRegistryController::class, 'destroy'])->name('techs.destroy');

    // ===================== POCs =====================
    Route::get('/pocs',                 [PocRegistryController::class, 'index'])->name('pocs.index');
    Route::get('/pocs/new',             [PocRegistryController::class, 'create'])->name('pocs.create');   // (kept)
    Route::post('/pocs/new',            [PocRegistryController::class, 'store'])->name('pocs.store');     // (kept)
    Route::get('/pocs/{poc}/edit',      [PocRegistryController::class, 'edit'])->name('pocs.edit');
    Route::put('/pocs/{poc}',           [PocRegistryController::class, 'update'])->name('pocs.update');
    Route::delete('/pocs/{poc}',        [PocRegistryController::class, 'destroy'])->name('pocs.destroy');

    // Sites directory (list + modal create)
    Route::get('/sites',  [SitesDirectoryController::class, 'index'])->name('sites.index');
    Route::post('/sites', [SitesDirectoryController::class, 'store'])->name('sites.store');

  // JSON endpoints for dependent selects
    Route::get('/geo/arrondissements/{department}', [SitesDirectoryController::class, 'arrondissements'])
        ->name('geo.arrondissements');
    Route::get('/geo/communes/{arrondissement}',    [SitesDirectoryController::class, 'communes'])
        ->name('geo.communes');

});

// Home → Dashboard
Route::get('/radio/dashboard', [DashboardController::class, 'index'])->name('dashboard.index');

// Programming (Excel → evaluation)
Route::prefix('program/schedules')->name('program.schedules.')->group(function () {
    Route::get('/', [ProgramScheduleController::class, 'index'])->name('index');
    Route::get('/upload', [ProgramScheduleController::class, 'uploadForm'])->name('upload');
    Route::post('/upload', [ProgramScheduleController::class, 'uploadStore']);
    Route::get('/template', [ProgramScheduleController::class, 'template'])->name('template');
    Route::get('/{batch}', [ProgramScheduleController::class, 'show'])->name('show');
    Route::post('/{batch}/evaluate', [ProgramScheduleController::class, 'evaluate'])->name('evaluate');
});

// Playout (what actually aired)
Route::prefix('playout')->name('playout.')->group(function () {
    Route::get('/logs', [PlayoutLogController::class, 'index'])->name('logs.index');
    Route::get('/logs/new', [PlayoutLogController::class, 'create'])->name('logs.new');
    Route::get('/logs/upload', [PlayoutLogController::class, 'uploadForm'])->name('logs.upload');
    Route::post('/logs/upload', [PlayoutLogController::class, 'uploadStore']);
    Route::get('/deviations', [PlayoutLogController::class, 'deviations'])->name('deviations.index');
});

// Technician Schedule
Route::prefix('tech')->name('tech.')->group(function () {
    Route::get('/schedule', [TechScheduleController::class, 'index'])->name('schedule.index');
    Route::get('/assignments', [TechAssignmentsController::class, 'index'])->name('assignments.index');
    Route::get('/assignments/new', [TechAssignmentsController::class, 'create'])->name('assignments.create');
    Route::get('/rota', [TechRotaController::class, 'index'])->name('rota.index');
    Route::get('/checkins', [TechCheckinsController::class, 'index'])->name('checkins.index');
    Route::post('/checkins', [TechCheckinsController::class, 'store'])->name('checkins.store');
    Route::post('/checkins/stations/{station}/toggle', [TechCheckinsController::class, 'toggleStation'])->name('checkins.station.toggle');
    Route::get('/availability', [TechAvailabilityController::class, 'index'])->name('availability.index');
});

// Maintenance
Route::prefix('maintenance')->name('maintenance.')->group(function () {
    Route::get('/tasks', [MaintenanceController::class, 'tasksIndex'])->name('tasks.index');
    Route::get('/tasks/new', [MaintenanceController::class, 'tasksCreate'])->name('tasks.create');
    Route::get('/calendar', [MaintenanceController::class, 'calendar'])->name('calendar.index');
});

// Monitoring
Route::prefix('monitoring')->name('monitoring.')->group(function () {
    Route::get('/source', [MonitoringController::class, 'source'])->name('source');
    Route::get('/hub', [MonitoringController::class, 'hub'])->name('hub');
    Route::get('/sites', [MonitoringController::class, 'sitesIndex'])->name('sites.index');
    Route::get('/sites/{site}', [MonitoringController::class, 'sitesShow'])->name('sites.show');
});

// Technician Daily Report (UI-only, fake data)
Route::get('/tech/reports/daily/new', [\App\Http\Controllers\RadioDashboard\Tech\TechReportsController::class, 'create'])
    ->name('tech.reports.daily.create');

// (Optional preview submit target, still UI-only)
Route::post('/tech/reports/daily/preview', [\App\Http\Controllers\RadioDashboard\Tech\TechReportsController::class, 'preview'])
    ->name('tech.reports.daily.preview');

    // routes/web.php
Route::get('/tech/reports/daily/new', fn() => view('radio_dashboard.tech.reports.daily_create'))
  ->name('tech.reports.daily.create');


// routes/web.php
Route::prefix('reports')->name('reports.')->group(function () {
  Route::get('/daily/technician', fn() => view('radio_dashboard.reports.daily_technician'))->name('daily.tech');
  Route::get('/daily/operator', fn() => view('radio_dashboard.reports.daily_operator'))->name('daily.op');
  Route::get('/daily/admin', fn() => view('radio_dashboard.reports.daily_admin'))->name('daily.admin');
  Route::get('/weekly', fn() => view('radio_dashboard.reports.weekly_summary'))->name('weekly');
    Route::get('/daily', [ReportsController::class, 'daily'])->name('daily');
    Route::get('/weekly', [ReportsController::class, 'weekly'])->name('weekly');
});


// ============================================
// Controllers moved under namespace App/Http/Controllers/RadioDashboard
// Each returns views under resources/views/radio_dashboard/*
// ============================================

// List / Edit / Update
Route::get('volunteers',              [VolunteersController::class, 'index'])->name('volunteers.index');
Route::get('volunteers/{id}/edit',    [VolunteersController::class, 'edit'])->name('volunteers.edit');
Route::put('volunteers/{id}',         [VolunteersController::class, 'update'])->name('volunteers.update');

// Activity (narrative)
Route::get('volunteers/{id}/activity', [VolunteersActivityController::class, 'index'])->name('volunteers.activity');
// If these controllers exist, uncomment the imports and routes below; otherwise keep disabled to avoid fatals.
// use App\Http\Controllers\FCMTokenController;
// use App\Http\Controllers\CorrectControllerName;
Route::middleware('throttle:10,1')->group(function () {
    Route::get('devotion/submit', [DevotionPublicController::class, 'create'])->name('devotion.public.create');
    Route::post('devotion/submit', [DevotionPublicController::class, 'store'])->name('devotion.public.store');
    Route::get('/communication_pap_devotions', [DevotionPublicController::class, 'index'])
    ->name('devotion.public.index');
});
/*
|--------------------------------------------------------------------------
| Web Routes — NO subdomain/campus routing
|--------------------------------------------------------------------------
| All routes work directly on the current domain (e.g. version2.gloryservant.com)
| Campus/subdomain groups and force.user.campus middleware have been removed.
*/

// -----------------------------------------------------
// Apex / Landing / Portal
// -----------------------------------------------------
Route::get('/', function () {
    return redirect('/login'); // or: return view('welcome');
});

Route::middleware('auth')->get('/admin-portal', [AdminPortalController::class, 'enter'])
    ->name('admin.portal');

Route::get('/notifications/dropdown', [NotificationController::class, 'dropdown'])
    ->name('notifications.dropdown')
    ->middleware('auth');
// -----------------------------------------------------
// ADMIN area (no subdomain) — guarded by web + auth + checkstatus + admin
// -----------------------------------------------------
Route::middleware(['web', 'auth', 'checkstatus', 'admin'])->group(function () {
    // Dashboards
    Route::get('/', [AdminDashboardController::class, 'index']);
    Route::get('dashboard', [AdminDashboardController::class, 'index'])->name('dashboard');

    // Employees
    Route::get('employees', 'Admin\\EmployeesController@index')->name('employees');
    Route::get('employees/new', 'Admin\\EmployeesController@new');
    Route::post('employee/add', 'Admin\\EmployeesController@add');

    // Employee Profile
    Route::get('profile-view-{id}', 'Admin\\ProfileController@view')->whereNumber('id');
    Route::get('profile/view/{id}', 'Admin\\ProfileController@view')->whereNumber('id');
    Route::get('profile/delete/{id}', 'Admin\\ProfileController@delete')->whereNumber('id');
    Route::post('profile/delete/employee', 'Admin\\ProfileController@clear');
    Route::get('profile/archive/{id}', 'Admin\\ProfileController@archive')->whereNumber('id');

    // Profile Info
    Route::get('profile/edit/{id}', 'Admin\\ProfileController@editPerson')->whereNumber('id');
    Route::post('profile-view-{id}', [ProfileController::class, 'updatePerson'])->whereNumber('id');

    // Attendance
    Route::get('attendance', 'Admin\\AttendanceController@index')->name('attendance');
    Route::get('attendance/edit/{id}', 'Admin\\AttendanceController@edit')->whereNumber('id');
    Route::get('attendance/delete/{id}', 'Admin\\AttendanceController@delete')->whereNumber('id');
    Route::post('attendance/update', 'Admin\\AttendanceController@update');
    Route::post('attendance/add-entry', 'Admin\\AttendanceController@addEntry');
    Route::get('attendance/filter', 'Admin\\AttendanceController@getFilter');

    // Schedules
    Route::get('schedules', 'Admin\\SchedulesController@index')->name('schedule');
    Route::post('schedules/add', 'Admin\\SchedulesController@add');
    Route::get('schedules/edit/{id}', 'Admin\\SchedulesController@edit')->whereNumber('id');
    Route::post('schedules/update', 'Admin\\SchedulesController@update');
    Route::get('schedules/delete/{id}', 'Admin\\SchedulesController@delete')->whereNumber('id');
    Route::get('schedules/archive/{id}', 'Admin\\SchedulesController@archive')->whereNumber('id');

    // Leaves
    Route::get('leaves', 'Admin\\LeavesController@index')->name('leave');
    Route::get('leaves/edit/{id}', 'Admin\\LeavesController@edit')->whereNumber('id');
    Route::get('leaves/delete/{id}', 'Admin\\LeavesController@delete')->whereNumber('id');
    Route::post('leaves/update', 'Admin\\LeavesController@update');

    // Users
    Route::get('users', 'Admin\\UsersController@index')->name('users');
    Route::get('users/enable/{id}', 'Admin\\UsersController@enable')->whereNumber('id');
    Route::get('users/disable/{id}', 'Admin\\UsersController@disable')->whereNumber('id');
    Route::get('users/edit/{id}', 'Admin\\UsersController@edit')->whereNumber('id');
    Route::get('users/delete/{id}', 'Admin\\UsersController@delete')->whereNumber('id');
    Route::post('users/register', 'Admin\\UsersController@register');
    Route::post('users/update/user', 'Admin\\UsersController@update');
    Route::post('users/update-worktype', 'Admin\\UsersController@updateWorkType');

    // Roles
    Route::get('roles', 'Admin\\RolesController@index')->name('roles');
    Route::post('users/roles/add', 'Admin\\RolesController@add');
    Route::get('user/roles/get', 'Admin\\RolesController@get');
    Route::post('users/roles/update', 'Admin\\RolesController@update');
    Route::get('users/roles/delete/{id}', 'Admin\\RolesController@delete')->whereNumber('id');
    Route::get('users/roles/permissions/edit/{id}', 'Admin\\RolesController@editperm')->whereNumber('id');
    Route::post('users/roles/permissions/update', 'Admin\\RolesController@updateperm');

    // Reports (admin UI)
    Route::get('reports', 'Admin\\ReportsController@index')->name('reports');
    Route::get('employee-list', 'Admin\\ReportsController@empList');
    Route::get('reports/employee-list', 'Admin\\ReportsController@empList');
    Route::get('reports/employee-attendance', 'Admin\\ReportsController@empAtten');
    Route::get('reports/individual-attendance', 'Admin\\ReportsController@indiAtten');
    Route::get('reports/employee-leaves', 'Admin\\ReportsController@empLeaves');
    Route::get('reports/individual-leaves', 'Admin\\ReportsController@indiLeaves');
    Route::get('employee-schedule', 'Admin\\ReportsController@empSched');
    Route::get('reports/organization-profile', 'Admin\\ReportsController@orgProfile');
    Route::get('volunteer-birthday', 'Admin\\ReportsController@empBday');
    Route::get('reports/user-accounts', 'Admin\\ReportsController@userAccs');
    Route::get('get/employee-attendance', 'Admin\\ReportsController@getEmpAtten');
    Route::get('get/employee-leaves', 'Admin\\ReportsController@getEmpLeav');
    Route::get('get/employee-schedules', 'Admin\\ReportsController@getEmpSched');

    // Settings
    Route::get('settings', 'Admin\\SettingsController@index')->name('settings');
    Route::post('settings/update', 'Admin\\SettingsController@update');
    Route::post('settings/reverse/activation', 'Admin\\SettingsController@reverse');
    Route::get('settings/get/app/info', 'Admin\\SettingsController@appInfo');

    // Fields
    Route::get('campus', 'Admin\\FieldsController@campus')->name('campus');
    Route::post('fields/campus/add', 'Admin\\FieldsController@addcampus');
    Route::get('fields/campus/delete/{id}', 'Admin\\FieldsController@deletecampus')->whereNumber('id');

    Route::get('ministry', 'Admin\\FieldsController@ministry')->name('ministry');
    Route::post('fields/ministry/add', 'Admin\\FieldsController@addministry');
    Route::get('fields/ministry/delete/{id}', 'Admin\\FieldsController@deleteministry')->whereNumber('id');

    Route::get('fields/jobtitle', 'Admin\\FieldsController@jobtitle')->name('jobtitle');
    Route::post('fields/jobtitle/add', 'Admin\\FieldsController@addJobtitle');
    Route::get('fields/jobtitle/delete/{id}', 'Admin\\FieldsController@deleteJobtitle')->whereNumber('id');

    Route::get('fields/leavetype', 'Admin\\FieldsController@leavetype')->name('leavetype');
    Route::post('fields/leavetype/add', 'Admin\\FieldsController@addLeavetype');
    Route::get('fields/leavetype/delete/{id}', 'Admin\\FieldsController@deleteLeavetype')->whereNumber('id');
    Route::get('fields/leavetype/leave-groups', 'Admin\\FieldsController@leaveGroups')->name('leavegroup');
    Route::post('fields/leavetype/leave-groups/add', 'Admin\\FieldsController@addLeaveGroups');
    Route::get('fields/leavetype/leave-groups/edit/{id}', 'Admin\\FieldsController@editLeaveGroups')->whereNumber('id');
    Route::post('fields/leavetype/leave-groups/update', 'Admin\\FieldsController@updateLeaveGroups');
    Route::get('fields/leavetype/leave-groups/delete/{id}', 'Admin\\FieldsController@deleteLeaveGroups')->whereNumber('id');

    // Exports / Imports (admin)
    Route::get('export/fields/campus', 'Admin\\ExportsController@campus');
    Route::get('export/fields/ministry', 'Admin\\ExportsController@ministry');
    Route::get('export/fields/jobtitle', 'Admin\\ExportsController@jobtitle');
    Route::get('export/fields/leavetypes', 'Admin\\ExportsController@leavetypes');

    Route::post('import/fields/campus', 'Admin\\ImportsController@importcampus');
    Route::post('import/fields/ministry', 'Admin\\ImportsController@importministry');
    Route::post('import/fields/jobtitle', 'Admin\\ImportsController@importJobtitle');
    Route::post('import/fields/leavetypes', 'Admin\\ImportsController@importLeavetypes');
    Route::post('import/options', 'Admin\\ImportsController@opt');

    Route::get('export/report/employees', 'Admin\\ExportsController@employeeList');
    Route::post('export/report/attendance', 'Admin\\ExportsController@attendanceReport');
    Route::post('export/report/leaves', 'Admin\\ExportsController@leavesReport');
    Route::get('export/report/birthdays', 'Admin\\ExportsController@birthdaysReport');
    Route::get('export/report/accounts', 'Admin\\ExportsController@accountReport');
    Route::post('export/report/schedule', 'Admin\\ExportsController@scheduleReport');
});



Route::middleware('throttle:10,1')->group(function () {
    Route::get('devotion/submit', [DevotionPublicController::class, 'create'])->name('devotion.public.create');
    Route::post('devotion/submit', [DevotionPublicController::class, 'store'])->name('devotion.public.store');
    Route::get('/communication_pap_devotions', [DevotionPublicController::class, 'index'])
    ->name('devotion.public.index');
});

// -----------------------------------------------------
// Employee (non-admin) area — web + auth + employee
// -----------------------------------------------------
Route::middleware(['web', 'auth', 'employee'])->group(function () {
    Route::get('personal/dashboard', 'Personal\\PersonalDashboardController@index');

    // profile
    Route::get('personal/profile/view', 'Personal\\PersonalProfileController@index')->name('myProfile');
    Route::get('personal/profile/edit', 'Personal\\PersonalProfileController@profileEdit');
    Route::post('personal/profile/update', 'Personal\\PersonalProfileController@profileUpdate');

    // attendance
    Route::get('personal/attendance/view', 'Personal\\PersonalAttendanceController@index');
    Route::get('get/personal/attendance', 'Personal\\PersonalAttendanceController@getPA');

    // schedules
    Route::get('personal/schedules/view', 'Personal\\PersonalSchedulesController@index');
    Route::get('get/personal/schedules', 'Personal\\PersonalSchedulesController@getPS');

    // leaves
    Route::get('personal/leaves/view', 'Personal\\PersonalLeavesController@index')->name('viewPersonalLeave');
    Route::get('personal/leaves/edit/{id}', 'Personal\\PersonalLeavesController@edit')->whereNumber('id');
    Route::post('personal/leaves/update', 'Personal\\PersonalLeavesController@update');
    Route::post('personal/leaves/request', 'Personal\\PersonalLeavesController@requestL');
    Route::get('personal/leaves/delete/{id}', 'Personal\\PersonalLeavesController@delete')->whereNumber('id');
    Route::get('get/personal/leaves', 'Personal\\PersonalLeavesController@getPL');
    Route::get('view/personal/leave', 'Personal\\PersonalLeavesController@viewPL');

    // settings + user
    Route::get('personal/settings', 'Personal\\PersonalSettingsController@index');
    Route::get('personal/update-user', 'Personal\\PersonalAccountController@viewUser')->name('changeUser');
    Route::get('personal/update-password', 'Personal\\PersonalAccountController@viewPassword')->name('changePass');
    Route::post('personal/update/user', 'Personal\\PersonalAccountController@updateUser');
    Route::post('personal/update/password', 'Personal\\PersonalAccountController@updatePassword');
});

// -----------------------------------------------------
// Inventory & Computers (admin UI pieces without global admin middleware)
// -----------------------------------------------------
Route::get('computers', [ComputerController::class, 'create'])->name('admin.computers');
Route::post('computers', [ComputerController::class, 'store'])->name('admin.computers.store');

Route::get('inventory', [InventoryController::class, 'create'])->name('admin.inventory-equipment');

Route::prefix('admin')->name('admin.')->group(function (){
    Route::get('inventory-equipment/create', [InventoryController::class, 'create'])->name('inventory-equipment.create');
    Route::post('inventory-equipment', [InventoryController::class, 'store'])->name('inventory-equipment.store');
    Route::get('inventory-equipment/{id}/edit', [InventoryController::class, 'edit'])->whereNumber('id')->name('inventory-equipment.edit');
    Route::match(['put','patch'], 'inventory-equipment/{id}', [InventoryController::class, 'update'])->whereNumber('id')->name('inventory-equipment.update');
    Route::delete('inventory-equipment/{id}', [InventoryController::class, 'destroy'])->whereNumber('id')->name('inventory-equipment.destroy');
});

// -----------------------------------------------------
// Devotion Reports (Admin)
// -----------------------------------------------------
Route::middleware(['auth', 'admin'])->group(function () {
    Route::get('devotions-reports', [DevotionReportController::class, 'index'])->name('admin.reports.devotions');
    Route::get('admin/reports/devotions', [DevotionReportController::class, 'index'])->name('admin.reports.devotions');
    Route::get('admin/reports/global-devotions', [DevotionReportController::class, 'GlobalDevotionReport'])->name('admin.reports.global-devotions');
    Route::get('admin/reports/devotions/data', [DevotionReportController::class, 'getData'])->name('admin.reports.devotions.data');
});

// Employee Attendance Reports (Admin)
Route::middleware(['auth', 'admin'])->group(function () {
    Route::get('admin/reports/employee-attendance', [AttendanceReportsController::class, 'index'])->name('admin.reports.employee-attendance');
    Route::get('admin/reports/attendance/data', [AttendanceReportsController::class, 'getData'])->name('admin.reports.attendance.data');
});

// -----------------------------------------------------
// Site Dashboard (non-admin overview) — keep existing if used
// -----------------------------------------------------
Route::get('dashboard-overview', [SiteDashboardController::class, 'showAttendanceOverview'])->name('dashboard.overview');

// -----------------------------------------------------
// Basic utilities / static files
// -----------------------------------------------------
Route::get('test-migration', function () { return 'Migration is working!'; });

Route::get('gloryservant-v2', function () {
    $file = public_path('gloryservant-v2/index.html');
    if (! file_exists($file)) {
        abort(404, "New UI not found at: {$file}");
    }
    return response()->file($file);
});

// -----------------------------------------------------
// Notifications (JSON endpoints)
// -----------------------------------------------------
Route::middleware('auth')->group(function () {
    Route::get('notifications', [NotificationController::class, 'list'])->name('notifications.list');
    Route::get('notifications/count', [NotificationController::class, 'count'])->name('notifications.count');
    Route::post('notifications/{id}/read', [NotificationController::class, 'read'])->whereNumber('id')->name('notifications.read');
    Route::post('notifications/read-all', [NotificationController::class, 'readAll'])->name('notifications.readAll');
});

// Notifications pages (views)
Route::get('notifications-text', function(){ return view('admin.notifications-text'); })
    ->name('notifications.page')->middleware('auth');
Route::get('personal/notifications', function(){ return view('personal.personal-notifications-view'); })
    ->name('personal.notifications')->middleware('auth');

// Fetch notifications data (AJAX)
Route::middleware('auth')->get('get-notifications', [SendMailController::class, 'getNotifications'])->name('get.notifications');

// -----------------------------------------------------
// Personal Devotion
// -----------------------------------------------------
Route::post('personal/devotion/post', [App\Http\Controllers\DevotionController::class, 'store']);
Route::get('personal/devotion/view', [App\Http\Controllers\DevotionController::class, 'viewDevotions']);
Route::get('get/personal/devotion', [App\Http\Controllers\DevotionController::class, 'getPersonalDevotions']);

// -----------------------------------------------------
// Admin Devotions / Asana
// -----------------------------------------------------
Route::middleware(['auth', 'admin'])->group(function () {
    Route::get('devotion', [AdminDevotionController::class, 'index'])->name('admin.devotion.index');
});

Route::prefix('admin')->middleware(['auth', 'admin'])->group(function () {
    Route::get('asana', [AdminAsanaController::class, 'index'])->name('admin.asana.index');
    Route::get('asana-portfolio', [AdminAsanaPortfolioController::class, 'index'])->name('admin.asana-portfolio.index');
});

// -----------------------------------------------------
// Attendance (public/auth endpoints)
// -----------------------------------------------------
Route::middleware(['auth'])->group(function () {
    Route::get('attendance/{meeting_code}', [AttendanceController::class, 'markAttendance'])->name('attendance.mark');
});

Route::middleware(['auth','admin'])->get('admin/attendance-links', [AdminAttendanceController::class, 'showLinks'])->name('admin.attendance.links');
Route::middleware(['auth'])->get('meeting_links', [PublicMeetingLinkController::class, 'index'])->name('admin.meeting_links');
Route::middleware(['auth'])->get('sendMail', [SendMailController::class, 'index'])->name('admin.sendMail');

// Team attendance display
Route::get('display-attendance', [DisplayAttendanceController::class, 'index'])->name('team-attendance');

// Meeting Attendance (non-admin view)
//Route::get('meeting-attendance', [PublicMeetingLinkController::class, 'attendanceView'])->name('meeting.attendance');


// -----------------------------------------------------
// Requests (user/admin)
// -----------------------------------------------------
Route::middleware(['auth'])->group(function () {
    Route::get('my-requests', [RequestController::class, 'index']);
    Route::get('request/create', [RequestController::class, 'create']);
    Route::post('request/store', [RequestController::class, 'store']);
});

Route::middleware(['auth', 'isAdmin'])->group(function () {
    Route::get('admin/requests', [AdminRequestController::class, 'index']);
    Route::get('admin/request/{id}', [AdminRequestController::class, 'show'])->whereNumber('id');
    Route::post('admin/request/{id}/respond', [AdminRequestController::class, 'respond'])->whereNumber('id');
});

// Alias (personal requests view)
Route::middleware(['auth'])->get('personal/requests/view', [RequestController::class, 'index']);

// -----------------------------------------------------
// Admin send alert
// -----------------------------------------------------
Route::get('admin/send-alert', [App\Http\Controllers\Admin\AlertController::class, 'create'])->name('admin.sendAlert');

// -----------------------------------------------------
// Static pages
// -----------------------------------------------------
Route::view('faq', 'faq');
Route::view('knowledge-base', 'knowledge-base');
Route::view('team-attendance', 'team-attendance');

// -----------------------------------------------------
// Send Mail / Notifications (duplicates deduped; keep one set)
// -----------------------------------------------------
Route::get('sendMail', [SendMailController::class, 'index'])->name('send.mail');
Route::post('sendMail', [SendMailController::class, 'sendNotification'])->name('send.notification');
Route::get('sent-notifications', [SendMailController::class, 'listNotifications'])->name('sent.notifications');
Route::delete('delete-notification/{notification_code}', [SendMailController::class, 'deleteNotification'])->name('delete.notification');
Route::get('duplicate-notification/{notification_code}', [SendMailController::class, 'duplicateNotification'])->name('duplicate.notification');

Route::middleware(['auth'])->group(function () {
    Route::get('notifications/fetch', [SendMailController::class, 'fetchNotifications'])->name('notifications.fetch');
    Route::post('notifications/mark-all-read', [SendMailController::class, 'markAllNotificationsRead'])->name('notifications.markAllAsRead');
});

// -----------------------------------------------------
// Tracking
// -----------------------------------------------------
Route::post('track-action', [UserTrackingController::class, 'trackAction']);
Route::get('report/user-activity', [UserTrackingController::class, 'showReport'])->name('report.user-activity');

// -----------------------------------------------------
// Auth / language / redirects
// -----------------------------------------------------
Route::middleware('auth')->get('/home', 'Personal\\PersonalDashboardController@index')
    ->name('home');

// Laravel auth scaffolding
Auth::routes();

// Language + logout + permission pages
Route::get('lang/{locale}', 'LanguageController@lang');
Route::get('logout', 'Auth\\LoginController@logout')->name('logout');
Route::view('account-disabled', 'errors.account-disabled')->name('disabled');
Route::view('account-not-found', 'errors.account-not-found')->name('notfound');
//Route::get('permission-denied', 'Personal\\PersonalDashboardController@index');
Route::get('permission-denied', function (Request $request) {
    $msg = $request->query('m', 'You don’t have permission to access this page.');
    session()->flash('denied', $msg);

    // Try to go back; if not possible, go home
    $prev = url()->previous();
    return $prev && $prev !== $request->fullUrl()
        ? redirect($prev)
        : redirect('/');
})->name('denied');

// -----------------------------------------------------
// Clock-in utilities
// -----------------------------------------------------
Route::get('clockin', function () { return view('clockin.qr'); })->name('clockin.show');
Route::get('scan', 'ClockController@scanQr')->middleware('auth');

Route::get('check-clockin', function(Request $request) {
    $idno = $request->query('idno');
    if (! $idno) {
        return response()->json(['clocked_in' => false]);
    }

    $today = today()->toDateString();
    $exists = DB::table('tbl_people_attendance')
        ->where('idno', $idno)
        ->whereDate('date', $today)
        ->exists();

    return response()->json(['clocked_in' => (bool) $exists]);
});

// Protect write endpoint
Route::post('attendance/addWebApp', 'ClockController@add')->middleware('auth');
