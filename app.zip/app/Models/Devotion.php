<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Devotion extends Model
{
    // If your table name isn’t “devotions”, uncomment and adjust:
    protected $table = 'tbl_people_devotion';
}