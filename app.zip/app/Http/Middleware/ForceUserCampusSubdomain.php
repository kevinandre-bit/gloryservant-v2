<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class ForceUserCampusSubdomain
{
    public function handle($request, Closure $next)
    {
        $user = Auth::user();
        if (!$user) return $next($request);

        $userSub = DB::table('vw_user_campus_subdomain')
            ->where('user_id', $user->id)
            ->value('subdomain');

        $hostSub = $request->route('campus'); // from {campus} in the domain pattern

        if ($userSub && $hostSub && $userSub !== $hostSub) {
            return redirect()->away('https://'.$userSub.'.'.config('app.base_domain').'/admin');
        }
        return $next($request);
    }
}