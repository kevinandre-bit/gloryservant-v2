<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;

class LoginController extends Controller
{
    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = 'home';

    /**
     * Override to clear any “intended” URL so everyone always
     * lands on $redirectTo.
     */
    protected function sendLoginResponse(Request $request)
    {
        // Clear any previously-intended URL
        $request->session()->forget('url.intended');

        // Regenerate session to prevent fixation
        $request->session()->regenerate();

        // Clear login throttling
        $this->clearLoginAttempts($request);

        // Redirect to either your authenticated hook or the fixed path
        return $this->authenticated($request, $this->guard()->user())
                ?: redirect($this->redirectPath());
    }


    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }
}
