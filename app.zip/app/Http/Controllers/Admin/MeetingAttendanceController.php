<?php
// app/Http/Controllers/Admin/MeetingAttendanceController.php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Carbon\Carbon;

class MeetingAttendanceController extends Controller
{
    // GET /meeting-attendance/{token} — mark immediately, then show result
    public function auto(Request $request, string $token)
{
    // 1) Look up link by token
    $link = DB::table('meeting_link')->where('token', $token)->first();
    if (!$link) {
        return $this->renderResult(false, 'Invalid or unknown meeting link.', $token, null, false);
    }

    // 2) Check expiry (if set)
    if (!empty($link->expires_at) && \Carbon\Carbon::parse($link->expires_at)->isPast()) {
        return $this->renderResult(false, 'This meeting link has expired.', $token, $link->title, false);
    }

    // 3) Must be logged in
    $user = $request->user();
    if (!$user) {
        return $this->renderResult(false, 'Please log in to check in.', $token, $link->title, false);
    }

    // --- Normalizers for eligibility (case/space/underscore tolerant)
    $norm = function ($s) {
        $s = (string) $s;
        $s = trim($s);
        $s = preg_replace('/[\s_]+/u', ' ', $s); // "Guest_service" ~ "Guest Service"
        return mb_strtolower($s, 'UTF-8');
    };
    $inGroup = function ($value, array $group) use ($norm) {
        if (empty($group)) return true; // open access when list empty
        $groupNorm = array_map($norm, $group);

        // Handle comma/semicolon separated values (e.g., "Avl, Communication")
        $pieces = preg_split('/[;,]/', (string) $value) ?: [];
        $pieces = $pieces ? array_map('trim', $pieces) : [(string) $value];

        foreach ($pieces as $p) {
            if (in_array($norm($p), $groupNorm, true)) return true;
        }
        return false;
    };

    // 4) Eligibility checks (campus/ministry/department)
    $campusData  = DB::table('tbl_campus_data')
        ->where('reference', $user->reference ?? $user->id)
        ->first();

    $userCampus   = $user->campus     ?? optional($campusData)->campus;
    $userMinistry = $user->ministry   ?? optional($campusData)->ministry;
    $userDept     = $user->department ?? optional($campusData)->department;

    // Decode JSON columns to arrays of strings
    $toStrings = fn($arr) => array_values(array_filter(array_map(fn($v) => trim((string)$v), (array)$arr)));
    $campusGroup   = $toStrings($link->campus_group   ? json_decode($link->campus_group, true)   : []);
    $ministryGroup = $toStrings($link->ministry_group ? json_decode($link->ministry_group, true) : []);
    $deptGroup     = $toStrings($link->dept_group     ? json_decode($link->dept_group, true)     : []);

    if (!$inGroup($userCampus,   $campusGroup))   {
        return $this->renderResult(false, 'This link is restricted to selected campuses.', $token, $link->title, false);
    }
    if (!$inGroup($userMinistry, $ministryGroup)) {
        return $this->renderResult(false, 'This link is restricted to selected ministries.', $token, $link->title, false);
    }
    if (!$inGroup($userDept,     $deptGroup))     {
        return $this->renderResult(false, 'This link is restricted to selected departments.', $token, $link->title, false);
    }

    // 5) Idempotent write: per user + meeting_id + day
    $meetingId = $link->id; // <-- use the link's primary key
    $today     = now()->toDateString();

    $already = DB::table('meeting_attendance')
        ->where('user_id', $user->id)
        ->where('meeting_id', $meetingId)              // <-- meeting_id, not token
        ->whereDate('meeting_date', $today)
        ->exists();

    if (!$already) {
        DB::table('meeting_attendance')->insert([
            'meeting_id'   => $meetingId,              // <-- set meeting_id
            'user_id'      => $user->id,
            'token'        => $token,
            'idno'         => $user->idno ?? null,
            'employee'     => $user->name ?? $user->email,
            'meeting' => $link->title,
            'description'  => $link->description ?? null,
            'meeting_date' => now(),                   // datetime; date() filter above handles “per day”
            'campus'       => $userCampus,
            'ministry'     => $userMinistry,
            'dept'         => $userDept,
            'created_at'   => now(),
            'updated_at'   => now(),
        ]);
    }

    // 6) Render a stable view
    $msg = $already
        ? 'You already checked in today. No duplicate entry added.'
        : 'Attendance Confirmed ✅';

    return $this->renderResult(true, $msg, $token, $link->title, $already);
}

    private function renderResult($ok, $message, $token, $meeting, $already)
    {
        return view('attendance.confirm', [
            'ok'             => (bool) $ok,
            'message'        => $message,
            'meeting'        => $meeting ?: 'Meeting',
            'token'          => $token,
            'alreadyChecked' => (bool) $already,
        ]);
    }
}