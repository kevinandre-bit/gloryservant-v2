<?php
// app/Http/Controllers/Admin/MeetingLinkController.php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Carbon\Carbon;
use SimpleSoftwareIO\QrCode\Facades\QrCode;
use Illuminate\Support\Facades\Cache;
Cache::forget('nav:meetings-links');
Cache::forget('nav:lists'); // only if you changed lists
class MeetingLinkController extends Controller
{
    /**
     * List meeting links + provide lists for modal (campus/ministry/dept)
     */
    public function index()
    {
        $meetings = DB::table('meeting_link')
            ->orderByDesc('id')
            ->get()
            ->map(function ($m) {
                $m->url    = url("/meeting-attendance/{$m->token}");
                $m->qr_url = $m->qr_path ? asset('storage/'.$m->qr_path) : null;
                $m->campus_group   = $m->campus_group   ? json_decode($m->campus_group, true)   : [];
                $m->ministry_group = $m->ministry_group ? json_decode($m->ministry_group, true) : [];
                $m->dept_group     = $m->dept_group     ? json_decode($m->dept_group, true)     : [];
                return $m;
            });

        // Pluck lists (adjust tables if yours differ)
        $campuses    = DB::table('tbl_form_campus')->distinct()->pluck('campus')->filter()->values()->toArray();
        $ministries  = DB::table('tbl_form_ministry')->distinct()->pluck('ministry')->filter()->values()->toArray();
        $departments = DB::table('tbl_form_department')->distinct()->pluck('department')->filter()->values()->toArray();

        return view('admin.reports.meeting_links', compact('meetings','campuses','ministries','departments'));
    }

    /**
     * Create a meeting link (date expiry, checkbox groups, QR generation)
     */
    public function store(Request $request)
    {
        $data = $request->validate([
            'title'              => 'required|string|max:150',
            'description'        => 'nullable|string|max:5000',
            'expires_in'         => 'nullable|date', // YYYY-MM-DD
            'campus_group'       => 'nullable|array',
            'campus_group.*'     => 'string|max:120',
            'ministry_group'     => 'nullable|array',
            'ministry_group.*'   => 'string|max:120',
            'dept_group'         => 'nullable|array',
            'dept_group.*'       => 'string|max:120',
        ]);

        // 24-hex token like your links
        $token = substr(bin2hex(random_bytes(16)), 0, 24);
        while (\DB::table('meeting_link')->where('token', $token)->exists()) {
            $token = substr(bin2hex(random_bytes(16)), 0, 24);
        }

        $attendanceUrl = url("/meeting-attendance/{$token}");

        // --- QR as SVG (no Imagick/GD needed) ---
        $svg = QrCode::format('svg')
            ->size(700)        // visual size
            ->margin(1)        // quiet zone
            ->generate($attendanceUrl);

        // Save directly under public/assets2/qr
        $fileName = "attendance_{$token}.svg";
        $filePath = public_path("assets2/qr/{$fileName}");
        file_put_contents($filePath, $svg);

        // Store relative path in DB (or full if you prefer)
        $qr_path = "assets2/qr/{$fileName}";
        // ----------------------------------------

        $expiresAt = !empty($data['expires_in'])
            ? Carbon::parse($data['expires_in'])->endOfDay()
            : null;

        $campusGroup   = isset($data['campus_group'])   ? json_encode(array_values(array_unique($data['campus_group'])))   : null;
        $ministryGroup = isset($data['ministry_group']) ? json_encode(array_values(array_unique($data['ministry_group']))) : null;
        $deptGroup     = isset($data['dept_group'])     ? json_encode(array_values(array_unique($data['dept_group'])))     : null;

        $id = \DB::table('meeting_link')->insertGetId([
            'title'          => $data['title'],
            'description'    => $data['description'] ?? null,
            'token'          => $token,
            'expires_at'     => $expiresAt,
            'qr_path'        => $qr_path,           // e.g. qr/attendance_xxx.svg
            'created_by'     => auth()->id(),
            'campus_group'   => $campusGroup,
            'ministry_group' => $ministryGroup,
            'dept_group'     => $deptGroup,
            'created_at'     => now(),
            'updated_at'     => now(),
        ]);

        return back()->with('success', 'Meeting link created successfully!');
    }
    // app/Http/Controllers/Admin/MeetingLinkController.php
    public function update(Request $req, $id)
    {
            $data = $req->validate([
                'title'              => 'required|string|max:150',
                'description'        => 'nullable|string|max:5000',
                'expires_in'         => 'nullable|date',
                'campus_group'       => 'nullable|array',
                'campus_group.*'     => 'string|max:120',
                'ministry_group'     => 'nullable|array',
                'ministry_group.*'   => 'string|max:120',
                'dept_group'         => 'nullable|array',
                'dept_group.*'       => 'string|max:120',
            ]);

            $expiresAt = !empty($data['expires_in'])
                ? \Carbon\Carbon::parse($data['expires_in'])->endOfDay()
                : null;

            \DB::table('meeting_link')->where('id', $id)->update([
                // keep legacy `name` synced if your schema requires it
                'title'           => $data['title'],
                'description'     => $data['description'] ?? null,
                'expires_at'      => $expiresAt,
                'campus_group'    => json_encode(array_values(array_unique($data['campus_group'] ?? []))),
                'ministry_group'  => json_encode(array_values(array_unique($data['ministry_group'] ?? []))),
                'dept_group'      => json_encode(array_values(array_unique($data['dept_group'] ?? []))),
                'updated_at'      => now(),
            ]);

            return back()->with('success', 'Meeting link updated successfully!');
        }
        public function destroy(int $id)
        {
            $row = DB::table('meeting_link')->where('id', $id)->first();
            if (!$row) {
                return back()->with('flash', [
                    'type' => 'danger',
                    'msg'  => 'Meeting link not found.',
                ]);
            }

            // Try to remove the QR file (best-effort)
            if (!empty($row->qr_path)) {
                $abs = public_path($row->qr_path);
                if (is_file($abs)) @unlink($abs);
            }

            DB::table('meeting_link')->where('id', $id)->delete();

            return back()->with('success', 'Meeting link deleted successfully!');
        }

}