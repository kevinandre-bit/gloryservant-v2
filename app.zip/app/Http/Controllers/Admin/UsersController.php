<?php

namespace App\Http\Controllers\Admin;
use DB;
use App\Classes\table;
use App\Classes\permission;
use App\Http\Requests;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Hash;
use App\Http\Controllers\Controller;
use App\Mail\NewUserWelcomeMail;
use Illuminate\Support\Facades\Mail;

class UsersController extends Controller
{
    /**
     * Display a list of users, roles, and employee records.
     */
    public function index()
    {
        // Check if the current user has permission to view users
        if (permission::permitted('users') == 'fail') {
            return redirect()->route('denied');
        }

        // Retrieve users with their role names
        $users_roles = table::users()
            ->join('users_roles', 'users.role_id', '=', 'users_roles.id')
            ->select('users.*', 'users_roles.role_name')
            ->get();

        // Retrieve all users, roles, and employee records
        $users = table::users()->get();
        $roles = table::roles()->get();
        $employees = table::people()->get(); 
        

        // Return the admin user management view with all data
        return view('admin.users', compact('users', 'roles', 'employees', 'users_roles'));
    }

    /**
     * Register a new user in the system.
     */
    public function register(Request $request)
    {
        // Check permission to add users
        if (permission::permitted('users-add') == 'fail') {
            return redirect()->route('denied');
        }

        // Validate incoming request data
        $v = $request->validate([
            'ref' => 'required|max:100',
            'name' => 'required|max:100',
            'email' => 'required|email|max:100',
            'role_id' => 'required|digits_between:1,99|max:2',
            'acc_type' => 'required|digits_between:1,99|max:2',
            'password' => 'required|min:8|max:100',
            'password_confirmation' => 'required|min:8|max:100',
            'status' => 'required|boolean|max:1',
        ]);

        // Assign request inputs to variables
        $ref = $request->ref;
        $name = $request->name;
        $email = $request->email;
        $role_id = $request->role_id;
        $acc_type = $request->acc_type;
        $password = $request->password;
        $password_confirmation = $request->password_confirmation;
        $status = $request->status;

        // Check if password matches confirmation
        if ($password != $password_confirmation) {
            return redirect('users')->with('error', trans("Whoops! Password confirmation does not match!"));
        }

        // Check if user already exists by email
        $is_user_exist = table::users()->where('email', $email)->count();
        if ($is_user_exist >= 1) {
            return redirect('users')->with('error', trans("Whoops! this user already exist"));
        }

        // Get employee ID number using the reference value
        $idno = table::campusdata()->where('reference', $ref)->value('idno');

        // Insert the new user into the database
        table::users()->insert([
            [
                'reference' => $ref,
                'idno' => $idno,
                'name' => $name,
                'email' => $email,
                'role_id' => $role_id,
                'acc_type' => $acc_type,
                'password' => Hash::make($password),
                'status' => $status,
            ],
        ]);

        // Send a welcome email to the new user
        Mail::to($email)->send(new NewUserWelcomeMail($email, $password, $idno));

        return redirect('/users')->with('success', trans("New user has been added."));
    }

    /**
     * Show the edit form for a specific user.
     */
    public function edit($id) 
    {
        // Check permission to edit users
        if (permission::permitted('users-edit') == 'fail') {
            return redirect()->route('denied');
        }

        // Retrieve the user record and list of roles
        $u = table::users()->where('id', $id)->first();
        $r = table::roles()->get();

        // Encrypt the reference value for use in forms
        $e_id = ($u->reference == null) ? 0 : Crypt::encryptString($u->reference);

        return view('admin.users', compact('u', 'r', 'e_id'));
    }

    /**
     * Update an existing user's details.
     */
    public function update(Request $request) 
    {
        // Check permission to edit users
        if (permission::permitted('users-edit') == 'fail') {
            return redirect()->route('denied');
        }

        // Validate required fields
        $v = $request->validate([
            'reference' => 'required|max:200',
            'role_id' => 'required|digits_between:1,99|max:2',
            'acc_type' => 'required|digits_between:1,99|max:2',
            'status' => 'required|boolean|max:1',
        ]);

        // Decrypt the reference and assign other inputs
        $ref = $request->reference;
        $role_id = $request->role_id;
        $acc_type = $request->acc_type;
        $password = $request->password;
        $password_confirmation = $request->password_confirmation;
        $status = $request->status;

        // Handle password update if provided
        if ($password !== null && $password_confirmation !== null) {
            $v = $request->validate([
                'password' => 'required|min:8|max:100',
                'password_confirmation' => 'required|min:8|max:100',
            ]);

            if ($password != $password_confirmation) {
                return redirect('users')->with('error', trans("Whoops! Password confirmation does not match!"));
            }

            // Update with new password
            table::users()->where('reference', $ref)->update([
                'role_id' => $role_id,
                'acc_type' => $acc_type,
                'status' => $status,
                'password' => Hash::make($password),
                'remember_token' => Hash::make($password),
            ]);
        } else {
            // Update without changing password
            table::users()->where('reference', $ref)->update([
                'role_id' => $role_id,
                'acc_type' => $acc_type,
                'status' => $status,
            ]);
        }

        return redirect('users')->with('success', trans("User Account has been updated!"));
    }


public static function alertModalData()
{
    return [
        'roles' => table::roles()->get(),
        'ministries' => table::tbl_form_ministry()->get(),
        'campuses' => table::tbl_form_campus()->get(),
        'employees' => table::tbl_people()->get(),
    ];
    return view('layouts.default', AlertController::alertModalData());

}

public function updateWorkType(Request $request)
{
    // Accept either 'id' or 'reference' (some parts of your app use 'reference')
    $payloadId = $request->input('id') ?? $request->input('reference');

    // Validate
    try {
        $request->validate([
            // validate a synthetic input 'payloadId' using Validator would be more complex,
            // so we do manual check here to allow either name.
            'work_type' => 'required|string|max:50',
        ]);
        if (empty($payloadId)) {
            throw ValidationException::withMessages(['id' => 'The id/reference field is required.']);
        }
    } catch (ValidationException $e) {
        return response()->json([
            'success' => false,
            'errors'  => $e->errors()
        ], 422);
    }

    $reference = $payloadId;
    $workType  = $request->input('work_type');

    try {
        $updated = DB::table('users')
            ->where('reference', $reference)
            ->update(['work_type' => $workType]);

        if ($updated) {
            return response()->json([
                'success' => true,
                'message' => 'Work type updated'
            ]);
        }

        // 0 rows updated — could be because record not found or same value
        return response()->json([
            'success' => false,
            'message' => 'No rows updated (record not found or value unchanged).'
        ], 200);

    } catch (\Throwable $ex) {
        Log::error('updateWorkType error: '.$ex->getMessage(), [
            'reference' => $reference,
            'work_type' => $workType,
        ]);

        return response()->json([
            'success' => false,
            'message' => 'Server error while updating work type'
        ], 500);
    }
}
    /**
     * Delete a user by ID.
     */
    public function delete($id, Request $request)
    {
        // Check permission to delete users
        if (permission::permitted('users-delete') == 'fail') {
            return redirect()->route('denied');
        }

        // Delete the user record
        table::users()->where('id', $id)->delete();

        return redirect('users')->with('success', trans("User Account has been deleted!"));
    }
}
