<?php
// app/Http/Controllers/Admin/MeetingAttendanceController.php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use Carbon\Carbon;

class InventoryVendorsController extends Controller
{

}