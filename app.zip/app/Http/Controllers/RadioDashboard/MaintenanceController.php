<?php

namespace App\Http\Controllers\RadioDashboard;

use App\Http\Controllers\Controller;
use Illuminate\Support\Carbon;

class MaintenanceController extends Controller
{
    public function tasksIndex()
    {
        // Fake summary stats
        $stats = [
            'open'      => 7,
            'overdue'   => 2,
            'scheduled' => 5,
            'doneThisWeek' => 9,
        ];

        // Fake tasks (UI only)
        $tasks = [
            [
                'id' => 101,
                'title' => 'Quarterly transmitter inspection',
                'site' => 'Ouest — Port-au-Prince',
                'type' => 'Preventive',
                'priority' => 'High',
                'due' => Carbon::now()->addDays(2)->toDateString(),
                'status' => 'Open',
                'assignee' => 'Jean T.',
                'notes' => 'Check PA stage temperature & fans.',
            ],
            [
                'id' => 102,
                'title' => 'Replace UPS batteries',
                'site' => 'Sud — Les Cayes',
                'type' => 'Corrective',
                'priority' => 'Medium',
                'due' => Carbon::now()->subDay()->toDateString(),
                'status' => 'Overdue',
                'assignee' => 'Michelet P.',
                'notes' => 'Low hold-up time reported.',
            ],
            [
                'id' => 103,
                'title' => 'Retune antenna jumper',
                'site' => 'Centre — Hinche',
                'type' => 'Corrective',
                'priority' => 'High',
                'due' => Carbon::now()->addDays(5)->toDateString(),
                'status' => 'Scheduled',
                'assignee' => 'Sabrina D.',
                'notes' => 'High VSWR, brief TX foldback.',
            ],
            [
                'id' => 104,
                'title' => 'Dust filters & rack cleaning',
                'site' => 'Grand’Anse — Jérémie',
                'type' => 'Preventive',
                'priority' => 'Low',
                'due' => Carbon::now()->addDays(7)->toDateString(),
                'status' => 'Open',
                'assignee' => 'Wilguens R.',
                'notes' => 'Humidity spikes last week.',
            ],
        ];

        return view('radio_dashboard.maintenance.tasks.index', compact('stats', 'tasks'));
    }

    public function calendar()
    {
        // Fake events (maintenance windows)
        $events = [
            [
                'date' => Carbon::now()->toDateString(),
                'title' => 'PAP: Replace STL encoder fan',
                'site' => 'Hub — Port-au-Prince',
                'window' => '10:00–11:30',
                'impact' => 'No on-air impact',
                'owner' => 'Admin',
                'type' => 'Corrective',
            ],
            [
                'date' => Carbon::now()->addDays(1)->toDateString(),
                'title' => 'Hinche: Preventive monthly',
                'site' => 'Centre — Hinche',
                'window' => '09:00–12:00',
                'impact' => 'Risk of short TX interruption',
                'owner' => 'Sabrina D.',
                'type' => 'Preventive',
            ],
            [
                'date' => Carbon::now()->addDays(3)->toDateString(),
                'title' => 'Les Cayes: UPS battery swap',
                'site' => 'Sud — Les Cayes',
                'window' => '14:00–16:00',
                'impact' => 'No on-air impact',
                'owner' => 'Michelet P.',
                'type' => 'Corrective',
            ],
        ];

        // Calendar scaffold (current month grid)
        $today = Carbon::now();
        $startOfMonth = $today->copy()->startOfMonth();
        $endOfMonth   = $today->copy()->endOfMonth();
        $startGrid    = $startOfMonth->copy()->startOfWeek(Carbon::MONDAY);
        $endGrid      = $endOfMonth->copy()->endOfWeek(Carbon::SUNDAY);

        return view('radio_dashboard.maintenance.calendar.index', compact(
            'events', 'today', 'startOfMonth', 'endOfMonth', 'startGrid', 'endGrid'
        ));
    }
}
