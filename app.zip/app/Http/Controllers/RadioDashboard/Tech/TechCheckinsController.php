<?php

namespace App\Http\Controllers\RadioDashboard\Tech;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use Illuminate\Support\Facades\Schema;

class TechCheckinsController extends Controller
{
    public function index()
    {
        // Sites list (from radio_stations)
        $sites = DB::table('radio_stations')
            ->select('id','name','on_air')
            ->orderBy('name')
            ->get();

        // Today window
        $start = Carbon::today();
        $end   = Carbon::tomorrow();

        // in TechCheckinsController@index, replace the checkins query end with ->get();
$checkins = DB::table('radio_checkins as c')
  ->leftJoin('users as u', 'u.id', '=', 'c.user_id')
  ->join('radio_stations as rs', 'rs.id', '=', 'c.station_id')
  ->orderByDesc('c.created_at')
  ->select(
      'c.id',
      'c.status',
      'c.note',
      'c.created_at',
      'rs.name as station_name',
      DB::raw('COALESCE(u.name, "—") as tech')
  )
  ->get();



        // Counts by status (today)
        $counts = [
                    'ok'    => DB::table('radio_checkins')->whereBetween('created_at',[$start,$end])->where('status','ok')->count(),
                    'issue' => DB::table('radio_checkins')->whereBetween('created_at',[$start,$end])->where('status','issue')->count(),
                    'power' => DB::table('radio_checkins')->whereBetween('created_at',[$start,$end])->where('status','power')->count(),
                    'link'  => DB::table('radio_checkins')->whereBetween('created_at',[$start,$end])->where('status','link')->count(),
                    'down'  => DB::table('radio_checkins')->whereBetween('created_at',[$start,$end])->where('status','down')->count(),
                ];

        return view('radio_dashboard.tech.checkins.index', compact('sites','checkins','counts'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'station_id' => 'required|integer|exists:radio_stations,id',
            'status'     => 'required|in:ok,issue,power,link',
            'note'       => 'nullable|string|max:1000',
        ]);

        $payload = [
            'station_id' => $validated['station_id'],
            'status'     => $validated['status'],
            'note'       => $validated['note'] ?? null,
            'user_id'    => Auth::id(),  // nullable if no auth
            'created_at' => now(),
        ];

        try {
            DB::table('radio_checkins')->insert($payload);
        } catch (\Throwable $e) {
            Log::error('radio_checkins insert failed', ['err'=>$e->getMessage(), 'payload'=>$payload]);
            return back()->withInput()->withErrors(['store'=>'Could not save check-in.']);
        }

        return back()->with('success','Check-in saved.');
    }

    // app/Http/Controllers/RadioDashboard/Tech/TechCheckinsController.php

    public function toggleStation(Request $request, int $station)
{
    $row = DB::table('radio_stations')->where('id', $station)->first(['on_air', 'name']);
    if (!$row) {
        return back()->with('error', 'Station not found.');
    }

    // If already ON, stop and tell user
    if ((int)$row->on_air === 1) {
        return back()->with('error', "Station '{$row->name}' is already On Air.");
    }

    try {
        // Force ON only
        DB::table('radio_stations')->where('id', $station)->update([
            'on_air'     => 1,
            'updated_at' => now(),
        ]);

        DB::table('radio_station_status_log')->insert([
            'station_id' => $station,
            'was_on_air' => (int)($row->on_air ?? 0),
            'now_on_air' => 1,
            'changed_by' => Auth::id(),
            'reason'     => $request->input('reason'),
            'created_at' => now(),
        ]);

        DB::table('radio_checkins')->insert([
            'station_id' => $station,
            'user_id'    => Auth::id(),
            'status'     => 'ok',
            'note'       => 'Back on air (toggle)',
            'created_at' => now(),
        ]);

    } catch (\Throwable $e) {
        Log::error('toggle on_air failed', [
            'err'=>$e->getMessage(),
            'station'=>$station,
        ]);
        return back()->with('error', 'Could not toggle On-Air. Please try again.');
    }

    return back()->with('success', "Station '{$row->name}' marked On Air (+ check-in + log).");
}
}