<?php

namespace App\Http\Controllers\RadioDashboard;

use App\Http\Controllers\Controller;

class DashboardController extends Controller
{
    public function index()
    {
        $radioDash = [
            'kpi' => [
                'matchPct'          => 93,                       // % aired as scheduled (yday)
                'networkUptimePct'  => 99.2,                     // lowest site 24h
                'criticalCount'     => 2,
                'lastUpdatedAt'     => now()->format('Y-m-d H:i'),
            ],

            // Programming & Playout
            'lastBatch' => [
                'period'   => 'Week 35',
                'filename' => 'program_grid_2025-W35.xlsx',
                'uploader' => 'Jane Doe',
                'when'     => '2h ago',
            ],
            'scheduleAdherence' => [ 'expected' => 720, 'aired' => 680 ],
            'adsTop5' => [
                ['name'=>'Sponsor A','pct'=>98],
                ['name'=>'Sponsor B','pct'=>93],
                ['name'=>'Sponsor C','pct'=>96],
                ['name'=>'Sponsor D','pct'=>88],
                ['name'=>'Sponsor E','pct'=>99],
            ],
            'reports' => [
                'technician' => ['ok'=>true,  'ts'=>'07:02'],
                'operator'   => ['ok'=>false, 'ts'=>null],
                'admin'      => ['ok'=>true,  'ts'=>'09:15'],
            ],
            'techCoverage' => [
                'assigned'=>8, 'total'=>10,
                'primary'=>'Pierre', 'backup'=>'Roland',
                'checkins'=>['received'=>7, 'total'=>10],
            ],

            // System — Source / Hub / Sites
            'source' => [
                'uptime24h' => 99.6,
                'series24h' => [98.5,98.7,98.9,99.1,99.0,99.3,99.6],
                'last_disconnect' => ['started_at'=>'05:42', 'duration'=>'2m'],
            ],
            'hub' => ['linksOk'=>9, 'linksTotal'=>10],
            'sitesUptime7d' => [
                ['name'=>'Ouest',      'up'=>99,'down'=>1],
                ['name'=>'Nord',       'up'=>98,'down'=>2],
                ['name'=>'Sud',        'up'=>97,'down'=>3],
                ['name'=>'Centre',     'up'=>99,'down'=>1],
                ['name'=>'Artibonite', 'up'=>96,'down'=>4],
            ],
            'snrSeries' => [22,24,26,23,25,27,24,22,23,24],

            // Alerts
            'alerts' => [
                ['id'=>1,'severity'=>'crit','title'=>'TX Sud down','site'=>'Sud','open_at'=>now()->subMinutes(14)->toIso8601String(),'grouped'=>2],
                ['id'=>2,'severity'=>'warn','title'=>'Low SNR at Ouest','site'=>'Ouest','open_at'=>now()->subMinutes(50)->toIso8601String()],
            ],

            // Timeline + Maintenance snapshot
            'upcoming' => [
                ['kind'=>'maintenance','title'=>'Planned power work','when'=>'Today 22:00','window'=>'2h','site'=>'Nord','owner'=>'Tech: Alex','impact'=>'Brief downtime','actions'=>['reschedule'=>'#','notify'=>'#','assign'=>'#']],
                ['kind'=>'event','title'=>'Live worship remote','when'=>'Fri 18:00','site'=>'Ouest','owner'=>'Ops: Marie','actions'=>['assign'=>'#']],
                ['kind'=>'compliance','title'=>'License renewal','when'=>'Aug 31','owner'=>'Admin: John','actions'=>['notify'=>'#']],
            ],
            'maintenance' => [
                'lastBySiteText'=>'Last maintenance: Ouest (Aug 12) • Nord (Aug 10) • Sud (Aug 8)',
                'overdue'=>3,
                'mttrHours'=>5.4,
                'topFaults'=>[
                    ['component'=>'Power','count'=>4],
                    ['component'=>'Backhaul','count'=>3],
                    ['component'=>'TX fan','count'=>2],
                ]
            ],

            // ===== Finance (NEW) =====
            'finance' => [
                'monthToDate' => 4120.50,   // optional KPI if you want to show it elsewhere
                'upcomingPayments' => [
                    // status: due_soon (<=3d), due (today), overdue (<today), scheduled (>3d)
                    ['due'=>'2025-08-25','vendor'=>'EDH (Electricity)','ref'=>'INV-EDH-0825','amount'=>2450.00,'currency'=>'USD','status'=>'due_soon','method'=>'Bank Transfer'],
                    ['due'=>'2025-08-25','vendor'=>'Digicel (Backhaul)','ref'=>'DG-0825','amount'=>890.00,'currency'=>'USD','status'=>'due_soon','method'=>'ACH'],
                    ['due'=>'2025-08-27','vendor'=>'HostGator (Hosting)','ref'=>'HG-0827','amount'=>29.99,'currency'=>'USD','status'=>'scheduled','method'=>'Card'],
                    ['due'=>'2025-08-23','vendor'=>'ISP (Internet)','ref'=>'ISP-0823','amount'=>320.00,'currency'=>'USD','status'=>'overdue','method'=>'ACH'],
                    ['due'=>'2025-08-25','vendor'=>'Fuel Supplier','ref'=>'FUEL-0825','amount'=>600.00,'currency'=>'USD','status'=>'due','method'=>'Cash'],
                    ['due'=>'2025-08-29','vendor'=>'Tower Lease','ref'=>'TWR-0829','amount'=>1100.00,'currency'=>'USD','status'=>'scheduled','method'=>'Bank Transfer'],
                    ['due'=>'2025-09-01','vendor'=>'Insurance','ref'=>'INS-0901','amount'=>450.00,'currency'=>'USD','status'=>'scheduled','method'=>'ACH'],
                    ['due'=>'2025-08-26','vendor'=>'Maintenance Parts','ref'=>'MP-0826','amount'=>210.35,'currency'=>'USD','status'=>'due_soon','method'=>'Card'],
                ],
                'routes' => [
                    'payNow' => '#',
                    'vendor' => route('finance.vendors.index'),
                    'recurring' => route('finance.recurring.index'),
                ]
            ],

            // Useful routes for other actions
            'routes' => [
                'validateGrid'    => route('program.schedules.index'),
                'requestReport'   => route('reports.daily'),
                'pingOnCall'      => route('tech.checkins.index'),
                'reprobe'         => route('monitoring.hub'),
                'ackAlert'        => '#',
                'createWorkOrder' => route('maintenance.tasks.index'),
                'assignTech'      => route('tech.assignments.index'),
                'addNote'         => route('maintenance.tasks.index'),
                'refresh'         => route('dashboard.index'),
            ],
        ];

        // Blade helpers
        $lastBatch = (object) ['period_label'=>'Week 35','original_filename'=>'program_grid_2025-W35.xlsx','uploader'=>(object)['name'=>'Jane'], 'created_at'=>now()->subHours(2)];
        $reports   = (object) ['technician'=>'Yes','operator'=>'No','admin'=>'Yes'];
        $onCall    = (object) ['primary'=>'Pierre','backup'=>'Roland'];
        $checkins  = (object) ['received'=>7,'total'=>10];
        $source    = (object) ['last_drop'=>'05:42 (2m)'];
        $coverage  = (object) ['assigned'=>8,'total'=>10];
        $critical  = [];

        return view('radio_dashboard.dashboard', compact('radioDash','lastBatch','reports','onCall','checkins','source','coverage','critical'));
    }
}