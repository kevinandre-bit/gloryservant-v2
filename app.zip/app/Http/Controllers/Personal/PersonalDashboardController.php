<?php

namespace App\Http\Controllers\Personal;
use DB;
use App\Classes\table;
use App\Classes\permission;
use App\Http\Requests;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class PersonalDashboardController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index() 
    {        
        $id = \Auth::user()->reference;
        $sm = date('m/01/Y');
        $em = date('m/31/Y');

        $cs = table::schedules()->where([
            ['reference', $id], 
            ['archive', '0']
        ])->first();

        $ps = table::schedules()->where([
            ['reference', $id],
            ['archive', '1'],
        ])->take(8)->get();

        $tf = table::settings()->value("time_format");

        $al = table::leaves()->where([['reference', $id], ['status', 'Approved']])->count();
        $ald = table::leaves()->where([['reference', $id], ['status', 'Approved']])->take(8)->get();
        $pl = table::leaves()->where([['reference', $id], ['status', 'Declined']])->orWhere([['reference', $id], ['status', 'Pending']])->count();
        $a = table::attendance()->where('reference', $id)->latest('date')->take(4)->get();

        $la = table::attendance()->where([['reference', $id], ['status_timein', 'Late Arrival']])->whereBetween('date', [$sm, $em])->count();
        $ed = table::attendance()->where([['reference', $id], ['status_timeout', 'Early Departure']])->whereBetween('date', [$sm, $em])->count();
        
        $total_user_tasks = DB::table('volunteer_tasks')
        ->where('reference', $id)
        ->where('completion_status', 'completed')
        ->sum('task_count');
        $today = date('m-d');

        $birthdaysToday = DB::table('tbl_people')
            ->join('tbl_campus_data', 'tbl_people.id', '=', 'tbl_campus_data.reference')
            ->select('tbl_people.firstname', 'tbl_people.lastname', 'tbl_campus_data.ministry', 'tbl_campus_data.campus')
            ->whereRaw('DATE_FORMAT(birthday, "%m-%d") = DATE_FORMAT(CURDATE(), "%m-%d")')
            ->get();

        return view('personal.personal-dashboard', compact('cs', 'ps', 'al', 'pl', 'ald', 'a', 'la', 'ed', 'tf', 'total_user_tasks','birthdaysToday'));
    }
}

