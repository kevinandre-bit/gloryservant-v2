<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class VolunteerProgress extends Model
{
    //
}
